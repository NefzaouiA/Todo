export const environment = {
  production: false,
  firebase: {
    apiKey: "fake-api-key",
    authDomain: "localhost",
    projectId: "demo-project",
    appId: "demo-app-id"
  }
};