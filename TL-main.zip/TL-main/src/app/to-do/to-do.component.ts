import { AccountManagementService } from './../account-management.service';
import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ToDoModel } from '../model/to-do-model';
import { ToDoService } from '../to-do.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-to-do',
  imports: [CommonModule, FormsModule],
  templateUrl: './to-do.component.html',
  styleUrl: './to-do.component.css',
})
export class ToDoComponent implements OnInit {
  listTodo: ToDoModel[] = [];
  message: string = '';
  editingIndex: number = -1;
  editMessage: string = '';

  constructor(
    public todoServ: ToDoService,
    public accountManagementService: AccountManagementService,
    public router: Router,
  ) {}

  ngOnInit(): void {
    // si vous etes pas authentifier ca ve dire vous avez pas un uid avec le quel vous avez travailer
    if (sessionStorage.getItem('userUid')) {
      this.accountManagementService.currentUser.uid =
        sessionStorage.getItem('userUid') || '';
      this.accountManagementService.currentUser.mail =
        sessionStorage.getItem('userMail') || '';
    } else {
      this.router.navigate(['/auth']);
    }

    this.todoServ
      .getTodos(this.accountManagementService.currentUser.uid)
      .subscribe(
        (res) => {
          this.listTodo = res;
        },

        (err) => {
          console.log(err);
        },
      );
  }

  public addTodo() {
    if (this.message == '') {
      return;
    }

    this.todoServ
      .addTodo({
        uid: null,
        uidUser: this.accountManagementService.currentUser.uid,
        message: this.message,
        check: false,
      })
      .then((res) => {
        this.message = '';
      })
      .catch((err) => console.error('ERROR', err));
  }

  // pour
  public changeCheck(index: number) {
    this.todoServ
      .updateTodo(this.listTodo[index].uid || '', {
        check: this.listTodo[index].check,
      })
      .then((res) => {})
      .catch((err) => {
        console.error(err);
      });
  }

  public deleteTodo(todo: ToDoModel) {
    if (todo.uid) {
      this.todoServ
        .deleteTodo(todo.uid)
        .then(() => {
          this.listTodo = this.listTodo.filter((t) => t.uid !== todo.uid);
        })
        .catch((err) => {
          console.error('Erreur lors de la suppression', err);
        });
    }
  }

  public logout() {
    this.accountManagementService.logout().then(() => {
      sessionStorage.removeItem('userUid');
      sessionStorage.removeItem('userMail');
      this.router.navigate(['/auth']);
    }).catch((err) => {
      console.error('Erreur lors de la déconnexion', err);
    });
  }

  public startEdit(index: number) {
    this.editingIndex = index;
    this.editMessage = this.listTodo[index].message;
  }

  public saveEdit(index: number) {
    if (this.editMessage.trim()) {
      this.listTodo[index].message = this.editMessage;
      this.todoServ
        .updateTodo(this.listTodo[index].uid || '', {
          message: this.editMessage,
        })
        .then(() => {
          this.editingIndex = -1;
          this.editMessage = '';
        })
        .catch((err) => {
          console.error('Erreur lors de la mise à jour', err);
        });
    }
  }

  public cancelEdit() {
    this.editingIndex = -1;
    this.editMessage = '';
  }
}
