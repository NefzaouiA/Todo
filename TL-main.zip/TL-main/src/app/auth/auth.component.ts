import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../auth.service';
import { AccountManagementService } from '../account-management.service';
import { Router, RouterLink } from "@angular/router";

@Component({
  selector: 'app-auth',
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './auth.component.html',
  styleUrl: './auth.component.css',
})
export class AuthComponent {
  mail: string = '';
  password: string = '';
  errorMessage: string = '';

  constructor(public accountMangeServ : AccountManagementService, public router: Router) {}

  public connect(): void {
    if (this.mail === '' && this.password === '') {
      this.errorMessage = 'Please fill in all fields.';
    } else {
      this.accountMangeServ.SignIn(this.mail, this.password)
      .then((res) => {
        this.accountMangeServ.currentUser.uid = res.user.uid;
        this.accountMangeServ.currentUser.mail = res.user.email || "";

        // INSERT_YOUR_CODE
        sessionStorage.setItem('userUid', this.accountMangeServ.currentUser.uid);
        sessionStorage.setItem('userMail', this.accountMangeServ.currentUser.mail);


        // routage vers todo list
        this.router.navigate(['/to-do']);
      })
      .catch((err) => {
        this.errorMessage = err.message;
      })
    }
  }
}
