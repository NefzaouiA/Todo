import { Routes } from '@angular/router';
import { AuthComponent } from './auth/auth.component';
import { CreateAccountComponent } from './create-account/create-account.component';
import { ToDoComponent } from './to-do/to-do.component';

export const routes: Routes = [
  { path: '', component: AuthComponent },

  { path: 'auth', component: AuthComponent },

  { path: 'creaete-account', component: CreateAccountComponent },

  {path: 'to-do', component: ToDoComponent}
];
