import { Injectable } from '@angular/core';
import {
  addDoc,
  collection,
  collectionData,
  deleteDoc,
  doc,
  Firestore,
  query,
  updateDoc,
  where,
} from '@angular/fire/firestore';
import { Observable } from 'rxjs';
import { ToDoModel } from './model/to-do-model';

@Injectable({
  providedIn: 'root',
})
export class ToDoService {
  constructor(private firestore: Firestore) {}

  public addTodo(todo: ToDoModel) {
    const todoRef = collection(this.firestore, 'todos');
    return addDoc(todoRef, {
      uidUser: todo.uidUser,
      message: todo.message,
      check: todo.check,
    });
  }

  public getTodos(user_id: string): Observable<ToDoModel[]> {
    const todoRef = collection(this.firestore, 'todos');
    const q = query(todoRef, where('uidUser', '==', user_id));
    return collectionData(q, { idField: 'uid' }) as Observable<ToDoModel[]>;
  }

  public getAllTodos(): Observable<ToDoModel[]> {
    const todoRef = collection(this.firestore, 'todos');
    return collectionData(todoRef, { idField: 'uid' }) as Observable<
      ToDoModel[]
    >;
  }

  // 🔹 Modifier
  updateTodo(id: string, data: Partial<ToDoModel>) {
    const todoDoc = doc(this.firestore, `todos/${id}`);
    return updateDoc(todoDoc, data);
  }

  // 🔹 Supprimer
  deleteTodo(id: string) {
    const todoDoc = doc(this.firestore, `todos/${id}`);
    return deleteDoc(todoDoc);
  }
}
