import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AccountManagementService } from '../account-management.service';
import { Router, RouterLink } from "@angular/router";

@Component({
  selector: 'app-create-account',
  imports: [CommonModule, FormsModule, RouterLink],
  templateUrl: './create-account.component.html',
  styleUrl: './create-account.component.css'
})
export class CreateAccountComponent {
  mail: string = '';
  password: string = '';
  message: string = '';

  constructor(public accountManagementService: AccountManagementService, public router : Router) {}

  public createAccount() {
    if(this.mail == "" || this.password == "") {
      this.message = "Veuillez remplir tous les champs.";
    }
    else {
      this.accountManagementService.createAccount(this.mail, this.password).then((res) => {
        this.accountManagementService.currentUser.uid = res.user.uid;
        this.accountManagementService.currentUser.mail = res.user.email || "";

        sessionStorage.setItem('userUid', this.accountManagementService.currentUser.uid);
        sessionStorage.setItem('userMail', this.accountManagementService.currentUser.mail);

        this.router.navigate(['/to-do'])

      }).catch((err) => {
        this.message = err.message;
      })
    }
  }
}
