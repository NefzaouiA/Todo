import { Injectable } from '@angular/core';
import { UserModel } from './model/user-model';
import { Auth, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut } from '@angular/fire/auth';

@Injectable({
  providedIn: 'root'
})
export class AccountManagementService {

  currentUser: UserModel = {
    uid: '',
    mail: '',
    password: ''
  }

  constructor(public authen : Auth) { }

  public createAccount(mail: string, password: string) {
    return createUserWithEmailAndPassword(this.authen, mail, password);
  }

  public SignIn(mail: string, password: string) {
    return signInWithEmailAndPassword(this.authen, mail, password);
  }

  public logout() {
    return signOut(this.authen);
  }
}
