// import { Injectable } from '@angular/core';
// import { addDoc, collection, collectionData, deleteDoc, doc, Firestore, updateDoc } from '@angular/fire/firestore';
// import { Observable } from 'rxjs';
// import { Todo } from '../models/todo';

// @Injectable({
//   providedIn: 'root'
// })
// export class TodoManagementService {

//   constructor(private firestore : Firestore) { }

 
//   // 🔹 Lire les données (temps réel)
//   getTodos(): Observable<Todo[]> {
//     const todoRef = collection(this.firestore, 'todos');
//     return collectionData(todoRef, { idField: 'id' }) as Observable<Todo[]>;
//   }

//   // 🔹 Ajouter
//   addTodo(todo: Todo) {
//     const todoRef = collection(this.firestore, 'todos');
//     return addDoc(todoRef, todo);
//   }

//   // 🔹 Supprimer
//   deleteTodo(id: string) {
//     const todoDoc = doc(this.firestore, `todos/${id}`); //todo/sihfqbdfqf la redirectoion
//     return deleteDoc(todoDoc);
//   }

//   // 🔹 Modifier
//   updateTodo(id: string, data: Partial<Todo>) {
//     const todoDoc = doc(this.firestore, `todos/${id}`);
//     return updateDoc(todoDoc, data);
//   }
// }
