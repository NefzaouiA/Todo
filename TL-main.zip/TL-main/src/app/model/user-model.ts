export interface UserModel {
    uid: string;
    mail: string;
    password: string;
}