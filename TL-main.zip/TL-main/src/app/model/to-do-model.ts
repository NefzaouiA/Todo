export interface ToDoModel {
    uid : string | null;
    uidUser : string;
    message : string;
    check : boolean;
}
