import { Component, createComponent } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { AuthComponent } from "./auth/auth.component";
import { CreateAccountComponent } from "./create-account/create-account.component";

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, AuthComponent, CreateAccountComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'pr';
}
