import { ApplicationConfig, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';

import { provideFirebaseApp, initializeApp } from '@angular/fire/app';
import { provideAuth, getAuth, connectAuthEmulator } from '@angular/fire/auth';
import { provideFirestore, getFirestore, connectFirestoreEmulator,} from '@angular/fire/firestore';
import { environment } from '../environment';
import { routes } from './app.routes';


export const appConfig: ApplicationConfig = {
  providers: [
    // Init Firebase (config fictive)
    provideFirebaseApp(() => initializeApp(environment.firebase)),

    // Auth Emulator
    provideAuth(() => {
      const auth = getAuth();
      connectAuthEmulator(auth, 'http://localhost:9099');
      return auth;
    }),

    // Firestore Emulator
    provideFirestore(() => {
      const firestore = getFirestore();
      connectFirestoreEmulator(firestore, 'localhost', 8081);
      return firestore;
    }),

    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes),
  ],
};
