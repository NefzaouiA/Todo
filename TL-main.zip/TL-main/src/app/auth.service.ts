import { Injectable } from '@angular/core';
import { Auth, createUserWithEmailAndPassword } from '@angular/fire/auth';
// import { UserModel } from './model/user';


@Injectable({
  providedIn: 'root',
})
export class AuthService {
  // userConnected : UserModel = {
  //   uid : '',
  //   mail : '',
  //   password : ''
  // }
  
  constructor(private auth: Auth) {}

  public create(mail: string, password: string) {
    return createUserWithEmailAndPassword(this.auth, mail, password);
  }
}
